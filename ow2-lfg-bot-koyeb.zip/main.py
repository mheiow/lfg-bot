import os
import asyncio
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import discord
from discord.ext import commands

# --- Tiny HTTP server for Koyeb health checks (FastAPI + Uvicorn) ---
from fastapi import FastAPI
from fastapi.responses import JSONResponse
import uvicorn

# --------------- CONFIG ---------------

INTENTS = discord.Intents.default()
INTENTS.message_content = True
INTENTS.members = True
INTENTS.reactions = True
INTENTS.guilds = True

BOT_PREFIX = "!"
TOKEN = os.getenv("DISCORD_TOKEN")

# Emojis for menus
EMOJI_LEFT = "◀️"
EMOJI_RIGHT = "▶️"
EMOJI_CONFIRM = "✅"
EMOJI_CANCEL = "❌"
EMOJI_SKIP = "🚫"

NUMS = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"]

EMOJI_ROLE_TANK = "🛡️"
EMOJI_ROLE_DAMAGE = "⚔️"
EMOJI_ROLE_SUPPORT = "✨"
EMOJI_ROLE_FLEX = "🔁"

EMOJI_MODE_COMP_ROLE = "🏆"
EMOJI_MODE_COMP_OPEN = "🔓"
EMOJI_MODE_QP_ROLE = "🎮"
EMOJI_MODE_QP_OPEN = "👐"
EMOJI_MODE_ARCADE = "🎲"
EMOJI_MODE_CUSTOM = "🏟️"

# Ranked tiers (OW2 S9+ includes Champion above GM)
RANKS = ["bronze", "silver", "gold", "platinum", "diamond", "master", "grandmaster", "champion"]

# Overwatch 2 hero roster (lowercase); includes S10+ heroes
HEROES = {
    "tank": [
        "d.va", "doomfist", "junker queen", "orisa", "ramattra", "reinhardt",
        "roadhog", "sigma", "winston", "wrecking ball", "zarya", "mauga"
    ],
    "damage": [
        "ashe", "bastion", "cassidy", "echo", "genji", "hanzo", "junkrat",
        "mei", "pharah", "reaper", "sojourn", "soldier: 76", "sombra",
        "symmetra", "torbjorn", "tracer", "widowmaker", "venture"
    ],
    "support": [
        "ana", "baptiste", "brigitte", "illari", "kiriko", "lifeweaver",
        "lucio", "mercy", "moira", "zenyatta"
    ]
}

HERO_ALIASES = {
    "dva": "d.va",
    "wreckingball": "wrecking ball",
    "soldier 76": "soldier: 76",
    "soldier:76": "soldier: 76",
    "torbjörn": "torbjorn",
    "lúcio": "lucio",
}

# Where to post final LFG embeds (guild_id -> channel_id). Ephemeral in-memory.
LFG_CHANNEL_MAP: Dict[int, int] = {}

# --------------- DATA MODELS ---------------

@dataclass
class Joiner:
    user_id: int
    role: Optional[str] = None          # tank/damage/support/flex
    hero: Optional[str] = None          # canonical hero name (lowercase)
    rank: Optional[str] = None          # for comp listings only

@dataclass
class LFGSession:
    guild_id: int
    author_id: int
    mode: Optional[str] = None          # comp_role, comp_open, qp_role, qp_open, arcade, custom
    role: Optional[str] = None          # tank/damage/support/flex
    hero: Optional[str] = None
    comp_rank_min: Optional[str] = None
    comp_rank_max: Optional[str] = None
    mic_required: bool = False
    players_needed: int = 4             # host + N == team size (default 5 stack target)
    listing_message_id: Optional[int] = None  # The final public listing message id
    listing_channel_id: Optional[int] = None  # Channel id where the listing is posted
    joiners: List[Joiner] = field(default_factory=list)

    def is_competitive(self) -> bool:
        return self.mode in ("comp_role", "comp_open")

    def gamemode_label(self) -> str:
        return {
            "comp_role": "Competitive (Role Queue)",
            "comp_open": "Competitive (Open Queue)",
            "qp_role": "Quick Play (Role Queue)",
            "qp_open": "Quick Play (Open Queue)",
            "arcade": "Arcade",
            "custom": "Custom Game",
        }.get(self.mode or "", "Unknown")

    def role_label(self) -> str:
        return {
            "tank": "Tank",
            "damage": "Damage",
            "support": "Support",
            "flex": "Flex (any role)",
        }.get(self.role or "", "Unknown")

# Active LFG posts: message_id -> LFGSession
ACTIVE_POSTS: Dict[int, LFGSession] = {}

# --------------- UTILITIES ---------------

def canonical_hero(name: str) -> str:
    key = name.strip().lower()
    if key in HERO_ALIASES:
        key = HERO_ALIASES[key]
    return key

def heroes_for_role(role: Optional[str]) -> List[str]:
    if role and role in HEROES:
        return HEROES[role]
    all_heroes = set()
    for lst in HEROES.values():
        all_heroes.update(lst)
    return sorted(all_heroes)

def is_hero_role_obj(role_obj: discord.Role) -> Optional[str]:
    n = role_obj.name.strip().lower()
    n = HERO_ALIASES.get(n, n)
    for lst in HEROES.values():
        if n in lst:
            return n
    return None

def detect_guild_hero_roles(guild: discord.Guild) -> Dict[str, discord.Role]:
    out: Dict[str, discord.Role] = {}
    for r in guild.roles:
        canon = is_hero_role_obj(r)
        if canon:
            out[canon] = r
    return out

async def add_many_reactions(msg: discord.Message, emojis: List[str]):
    for e in emojis:
        try:
            await msg.add_reaction(e)
        except discord.HTTPException:
            pass

async def wait_for_reaction_choice(bot: commands.Bot, msg: discord.Message, user: discord.abc.User, valid: List[str], timeout: float = 90.0) -> Optional[str]:
    def check(payload: discord.RawReactionActionEvent):
        return (
            payload.user_id == user.id and
            payload.message_id == msg.id and
            str(payload.emoji) in valid
        )
    try:
        payload = await bot.wait_for("raw_reaction_add", check=check, timeout=timeout)
        return str(payload.emoji)
    except asyncio.TimeoutError:
        return None

def build_summary_embed(session: LFGSession, author: discord.Member, join_count: int = 0) -> discord.Embed:
    title = f"LFG • {session.gamemode_label()}"
    e = discord.Embed(title=title, color=discord.Color.blurple())
    e.set_author(name=str(author), icon_url=author.display_avatar.url if author.display_avatar else discord.Embed.Empty)

    role_line = f"**Role**: {session.role_label()}"
    hero_line = f"**Hero**: {session.hero or 'any'}"
    mic_line = f"**Mic**: {'required' if session.mic_required else 'optional'}"
    players_line = f"**Players needed**: {session.players_needed}"

    e.add_field(name="Setup", value=f"{role_line}\n{hero_line}\n{mic_line}\n{players_line}", inline=False)

    if session.is_competitive():
        rr = f"{session.comp_rank_min or '?'} — {session.comp_rank_max or '?'}"
        e.add_field(name="Competitive Preferences", value=f"**Rank range**: {rr}", inline=False)

    if join_count:
        e.set_footer(text=f"{join_count} player(s) queued to join")
    return e

def build_listing_embed(session: LFGSession, author: discord.Member, guild: discord.Guild) -> discord.Embed:
    join_names = []
    for j in session.joiners:
        member = guild.get_member(j.user_id)
        if member:
            label_bits = []
            if j.role:
                label_bits.append(j.role.title())
            if j.hero:
                label_bits.append(j.hero)
            if session.is_competitive() and j.rank:
                label_bits.append(j.rank.title())
            tag = ", ".join(label_bits) if label_bits else "joined"
            join_names.append(f"- {member.mention} ({tag})")
    joined_text = "\\n".join(join_names) if join_names else "*No joiners yet.*"

    e = build_summary_embed(session, author, join_count=len(session.joiners))
    e.add_field(name="Joiners", value=joined_text, inline=False)
    if len(session.joiners) >= session.players_needed:
        e.color = discord.Color.green()
        e.description = "**Status: FULL**"
    else:
        e.description = f"React with {EMOJI_CONFIRM} to join • {EMOJI_CANCEL} to leave • {EMOJI_RIGHT} to open a team thread"
    return e

# --------------- BOT ---------------

bot = commands.Bot(command_prefix=BOT_PREFIX, intents=INTENTS, help_command=None)

def set_lfg_channel(guild_id: int, channel_id: int):
    LFG_CHANNEL_MAP[guild_id] = channel_id

def get_lfg_channel(guild: discord.Guild) -> discord.abc.Messageable:
    ch_id = LFG_CHANNEL_MAP.get(guild.id)
    if ch_id:
        ch = guild.get_channel(ch_id)
        if ch:
            return ch
    for ch in guild.text_channels:
        if ch.permissions_for(guild.me).send_messages:
            return ch
    raise RuntimeError("No writable channel found.")

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (id {bot.user.id})")

@bot.command(name="help")
async def help_cmd(ctx: commands.Context):
    embed = discord.Embed(title="Overwatch 2 LFG Bot — Help", color=discord.Color.blurple(),
                          description=(
                              f"**{BOT_PREFIX}lfg** — start an LFG setup via reactions\\n"
                              f"**{BOT_PREFIX}lfg_set #channel** — set the channel where final LFG posts go\\n"
                              "Tips:\\n"
                              "• Create roles that match hero names in all lowercase (e.g., `mei`, `venture`).\\n"
                              "• Players react to join; the bot DMs joiners to pick role/hero and rank (if Competitive).\\n"
                          ))
    await ctx.reply(embed=embed, mention_author=False)

@bot.command(name="lfg_set")
@commands.has_permissions(manage_guild=True)
async def lfg_set(ctx: commands.Context, channel: discord.TextChannel):
    set_lfg_channel(ctx.guild.id, channel.id)
    await ctx.reply(f"✅ LFG posts will be sent to {channel.mention}", mention_author=False)

@bot.command(name="lfg")
async def lfg_cmd(ctx: commands.Context):
    if not ctx.guild:
        return await ctx.reply("Please use this in a server.")
    author: discord.Member = ctx.author

    session = LFGSession(guild_id=ctx.guild.id, author_id=author.id)

    setup_msg = await ctx.reply("Setting up your LFG…", mention_author=False)
    can_create_thread = True
    setup_channel = ctx.channel
    try:
        thread = await setup_msg.create_thread(name=f"LFG setup — {author.display_name}", auto_archive_duration=60)
        setup_channel = thread
    except discord.HTTPException:
        can_create_thread = False

    # Step 1: Gamemode
    embed = discord.Embed(title="Step 1 — Choose a game mode", color=discord.Color.blurple(),
                          description=(
                              f"{EMOJI_MODE_COMP_ROLE} Competitive (Role Queue)\\n"
                              f"{EMOJI_MODE_COMP_OPEN} Competitive (Open Queue)\\n"
                              f"{EMOJI_MODE_QP_ROLE} Quick Play (Role Queue)\\n"
                              f"{EMOJI_MODE_QP_OPEN} Quick Play (Open Queue)\\n"
                              f"{EMOJI_MODE_ARCADE} Arcade\\n"
                              f"{EMOJI_MODE_CUSTOM} Custom Game\\n\\n"
                              "React below to choose."
                          ))
    step_msg = await setup_channel.send(embed=embed)
    gm_valid = [EMOJI_MODE_COMP_ROLE, EMOJI_MODE_COMP_OPEN, EMOJI_MODE_QP_ROLE, EMOJI_MODE_QP_OPEN, EMOJI_MODE_ARCADE, EMOJI_MODE_CUSTOM]
    for e in gm_valid:
        await step_msg.add_reaction(e)

    choice = await wait_for_reaction_choice(bot, step_msg, author, gm_valid)
    if choice is None:
        return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
    session.mode = {
        EMOJI_MODE_COMP_ROLE: "comp_role",
        EMOJI_MODE_COMP_OPEN: "comp_open",
        EMOJI_MODE_QP_ROLE: "qp_role",
        EMOJI_MODE_QP_OPEN: "qp_open",
        EMOJI_MODE_ARCADE: "arcade",
        EMOJI_MODE_CUSTOM: "custom",
    }[choice]

    # Step 2: Role
    embed = discord.Embed(title="Step 2 — Choose your role (Role Queue)", color=discord.Color.blurple(),
                          description=(
                              f"{EMOJI_ROLE_TANK} Tank\\n"
                              f"{EMOJI_ROLE_DAMAGE} Damage\\n"
                              f"{EMOJI_ROLE_SUPPORT} Support\\n"
                              f"{EMOJI_ROLE_FLEX} Flex (any)\\n\\n"
                              "React below to choose."
                          ))
    await step_msg.edit(embed=embed)
    role_valid = [EMOJI_ROLE_TANK, EMOJI_ROLE_DAMAGE, EMOJI_ROLE_SUPPORT, EMOJI_ROLE_FLEX]
    await step_msg.clear_reactions()
    for e in role_valid:
        await step_msg.add_reaction(e)

    choice = await wait_for_reaction_choice(bot, step_msg, author, role_valid)
    if choice is None:
        return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
    session.role = {
        EMOJI_ROLE_TANK: "tank",
        EMOJI_ROLE_DAMAGE: "damage",
        EMOJI_ROLE_SUPPORT: "support",
        EMOJI_ROLE_FLEX: "flex",
    }[choice]

    # Step 3: Hero pick (paged; based on server hero roles if available)
    guild_hero_roles = detect_guild_hero_roles(ctx.guild)
    allowed_heroes = heroes_for_role(session.role if session.role != "flex" else None)
    role_bound = [h for h in allowed_heroes if h in guild_hero_roles]
    display_heroes = role_bound if role_bound else allowed_heroes

    page = 0
    page_size = 9

    def hero_page_embed(pg: int) -> discord.Embed:
        start = pg * page_size
        items = display_heroes[start:start+page_size]
        lines = []
        for idx, h in enumerate(items, start=1):
            num = NUMS[idx-1]
            lines.append(f"{num} {h}")
        footer = "Pick a hero by reacting with a number. Use ◀️ ▶️ to change page, 🚫 to skip."
        e = discord.Embed(title="Step 3 — Choose your hero", color=discord.Color.blurple(),
                          description="\\n".join(lines) if lines else "*No hero roles detected; skipping is fine.*")
        e.set_footer(text=footer)
        return e

    await step_msg.clear_reactions()
    await step_msg.edit(embed=hero_page_embed(page))
    nav = [EMOJI_LEFT] + NUMS + [EMOJI_RIGHT, EMOJI_SKIP]
    for e in nav:
        await step_msg.add_reaction(e)

    while True:
        choice = await wait_for_reaction_choice(bot, step_msg, author, nav)
        if choice is None:
            return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
        if choice == EMOJI_LEFT:
            page = max(0, page-1)
            await step_msg.edit(embed=hero_page_embed(page))
            continue
        if choice == EMOJI_RIGHT:
            max_page = (len(display_heroes)-1) // page_size if display_heroes else 0
            page = min(max_page, page+1)
            await step_msg.edit(embed=hero_page_embed(page))
            continue
        if choice == EMOJI_SKIP:
            session.hero = None
            break
        if choice in NUMS:
            idx = NUMS.index(choice)
            start = page * page_size
            items = display_heroes[start:start+page_size]
            if idx < len(items):
                session.hero = items[idx]
            else:
                session.hero = None
            break

    # Step 4: Competitive rank range (only for comp modes)
    if session.is_competitive():
        rank_lines = "\\n".join(f\"{NUMS[i]} {r.title()}\" for i, r in enumerate(RANKS))
        embed = discord.Embed(title="Step 4 — Competitive rank range",
                              description=(
                                  "**Pick your **minimum** rank preference** (Competitive listings only).\\n"
                                  "This is a *preference* to filter joiners.\\n\\n"
                                  f"{rank_lines}\\n\\nReact with a number."
                              ),
                              color=discord.Color.blurple())
        await step_msg.clear_reactions()
        await step_msg.edit(embed=embed)
        for e in NUMS[:len(RANKS)]:
            await step_msg.add_reaction(e)
        choice = await wait_for_reaction_choice(bot, step_msg, author, NUMS[:len(RANKS)])
        if choice is None:
            return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
        rmin = RANKS[NUMS.index(choice)]
        session.comp_rank_min = rmin

        embed = discord.Embed(title="Step 4 — Competitive rank range",
                              description=(
                                  f"**Minimum** set to **{rmin.title()}**.\\n"
                                  "Now pick your **maximum** rank preference.\\n\\n"
                                  f"{rank_lines}\\n\\nReact with a number."
                              ),
                              color=discord.Color.blurple())
        await step_msg.clear_reactions()
        await step_msg.edit(embed=embed)
        for e in NUMS[:len(RANKS)]:
            await step_msg.add_reaction(e)
        choice = await wait_for_reaction_choice(bot, step_msg, author, NUMS[:len(RANKS)])
        if choice is None:
            return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
        rmax = RANKS[NUMS.index(choice)]
        if RANKS.index(rmax) < RANKS.index(rmin):
            rmin, rmax = rmax, rmin
        session.comp_rank_min, session.comp_rank_max = rmin, rmax

    # Step 5: Mic + players-needed
    embed = discord.Embed(title="Step 5 — Mic & party size", color=discord.Color.blurple(),
                          description=(
                              f"Toggle mic requirement with {EMOJI_CONFIRM} (on) / {EMOJI_CANCEL} (off). Currently **off**.\\n"
                              "Then choose players needed with a number (1–4)."
                          ))
    await step_msg.clear_reactions()
    await step_msg.edit(embed=embed)
    for e in [EMOJI_CONFIRM, EMOJI_CANCEL] + NUMS[:4]:
        await step_msg.add_reaction(e)

    choice = await wait_for_reaction_choice(bot, step_msg, author, [EMOJI_CONFIRM, EMOJI_CANCEL])
    if choice is None:
        return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
    session.mic_required = (choice == EMOJI_CONFIRM)

    choice = await wait_for_reaction_choice(bot, step_msg, author, NUMS[:4])
    if choice is None:
        return await setup_channel.send("⏱️ Setup timed out. Run `!lfg` again.")
    session.players_needed = NUMS.index(choice) + 1

    summary = build_summary_embed(session, author)
    summary.set_footer(text=f"React with {EMOJI_CONFIRM} to post this to the LFG channel, or {EMOJI_CANCEL} to cancel.")
    await step_msg.clear_reactions()
    await step_msg.edit(embed=summary)
    for e in [EMOJI_CONFIRM, EMOJI_CANCEL]:
        await step_msg.add_reaction(e)

    choice = await wait_for_reaction_choice(bot, step_msg, author, [EMOJI_CONFIRM, EMOJI_CANCEL])
    if choice != EMOJI_CONFIRM:
        return await setup_channel.send("❎ LFG creation cancelled.")

    target_channel = get_lfg_channel(ctx.guild)
    listing = await target_channel.send(embed=build_listing_embed(session, author, ctx.guild))
    session.listing_message_id = listing.id
    session.listing_channel_id = target_channel.id
    ACTIVE_POSTS[listing.id] = session

    for e in [EMOJI_CONFIRM, EMOJI_CANCEL, EMOJI_RIGHT]:
        await listing.add_reaction(e)
    await setup_channel.send(f"✅ LFG posted in {target_channel.mention}.")
    if can_create_thread and isinstance(setup_channel, discord.Thread):
        try:
            await setup_channel.edit(locked=True, archived=True)
        except discord.HTTPException:
            pass

async def prompt_joiner_setup(message: discord.Message, member: discord.Member, session: LFGSession):
    try:
        dm = await member.create_dm()
    except discord.HTTPException:
        return False

    role_msg = await dm.send(
        embed=discord.Embed(
            title="Join LFG — Choose your role",
            description=f"{EMOJI_ROLE_TANK} Tank\\n{EMOJI_ROLE_DAMAGE} Damage\\n{EMOJI_ROLE_SUPPORT} Support\\n{EMOJI_ROLE_FLEX} Flex (any)\\n\\nReact to choose.",
            color=discord.Color.blurple()
        )
    )
    for e in [EMOJI_ROLE_TANK, EMOJI_ROLE_DAMAGE, EMOJI_ROLE_SUPPORT, EMOJI_ROLE_FLEX]:
        await role_msg.add_reaction(e)
    emoji = await wait_for_reaction_choice(bot, role_msg, member, [EMOJI_ROLE_TANK, EMOJI_ROLE_DAMAGE, EMOJI_ROLE_SUPPORT, EMOJI_ROLE_FLEX], timeout=120)
    if not emoji:
        await dm.send("⏱️ Timed out.")
        return False
    role = {EMOJI_ROLE_TANK:"tank", EMOJI_ROLE_DAMAGE:"damage", EMOJI_ROLE_SUPPORT:"support", EMOJI_ROLE_FLEX:"flex"}[emoji]

    guild = message.guild
    hero_roles = detect_guild_hero_roles(guild)
    member_hero_candidates = []
    for r in member.roles:
        canon = is_hero_role_obj(r)
        if canon:
            member_hero_candidates.append(canon)
    if role != "flex":
        member_hero_candidates = [h for h in member_hero_candidates if h in HEROES[role]]

    display_heroes = member_hero_candidates if member_hero_candidates else (heroes_for_role(role if role != "flex" else None))

    page = 0
    page_size = 9
    async def show_page(pg: int):
        start = pg * page_size
        items = display_heroes[start:start+page_size]
        lines = [f"{NUMS[i]} {h}" for i, h in enumerate(items)]
        txt = "\\n".join(lines) if lines else "*No heroes found; skip if you like.*"
        e = discord.Embed(title="Choose your hero", description=txt + f"\\n\\nUse {EMOJI_LEFT} {EMOJI_RIGHT} to page, {EMOJI_SKIP} to skip.",
                          color=discord.Color.blurple())
        await hero_msg.edit(embed=e)

    hero_msg = await dm.send("Loading hero list…")
    for e in [EMOJI_LEFT] + NUMS + [EMOJI_RIGHT, EMOJI_SKIP]:
        await hero_msg.add_reaction(e)
    await show_page(page)

    hero_sel: Optional[str] = None
    while True:
        emoji = await wait_for_reaction_choice(bot, hero_msg, member, [EMOJI_LEFT]+NUMS+[EMOJI_RIGHT,EMOJI_SKIP], timeout=120)
        if not emoji:
            await dm.send("⏱️ Timed out.")
            return False
        if emoji == EMOJI_LEFT:
            page = max(0, page-1)
            await show_page(page)
            continue
        if emoji == EMOJI_RIGHT:
            max_pg = (len(display_heroes)-1)//page_size if display_heroes else 0
            page = min(max_pg, page+1)
            await show_page(page)
            continue
        if emoji == EMOJI_SKIP:
            break
        if emoji in NUMS:
            idx = NUMS.index(emoji)
            start = page*page_size
            items = display_heroes[start:start+page_size]
            if idx < len(items):
                hero_sel = items[idx]
            break

    rank_sel: Optional[str] = None
    if session.is_competitive():
        rank_lines = "\\n".join(f\"{NUMS[i]} {r.title()}\" for i, r in enumerate(RANKS))
        rmsg = await dm.send(embed=discord.Embed(
            title="Competitive Join — Pick your rank",
            description=f"{rank_lines}\\n\\nReact with a number.",
            color=discord.Color.blurple()
        ))
        for e in NUMS[:len(RANKS)]:
            await rmsg.add_reaction(e)
        emoji = await wait_for_reaction_choice(bot, rmsg, member, NUMS[:len(RANKS)], timeout=120)
        if not emoji:
            await dm.send("⏱️ Timed out.")
            return False
        rank_sel = RANKS[NUMS.index(emoji)]

        if session.comp_rank_min and session.comp_rank_max:
            if not (RANKS.index(session.comp_rank_min) <= RANKS.index(rank_sel) <= RANKS.index(session.comp_rank_max)):
                await dm.send(f"⚠️ Your rank **{rank_sel.title()}** is outside the host's preferred range "
                              f"(**{session.comp_rank_min.title()}–{session.comp_rank_max.title()}**).")
                return False

    j = Joiner(user_id=member.id, role=role, hero=hero_sel, rank=rank_sel)
    session.joiners = [x for x in session.joiners if x.user_id != member.id] + [j]
    await dm.send("✅ You're in! Check the LFG post.")
    return True

@bot.event
async def on_raw_reaction_add(payload: discord.RawReactionActionEvent):
    if payload.user_id == bot.user.id:
        return
    msg_id = payload.message_id
    if msg_id not in ACTIVE_POSTS:
        return
    guild = bot.get_guild(payload.guild_id) if payload.guild_id else None
    if not guild:
        return
    channel = guild.get_channel(payload.channel_id)
    if not isinstance(channel, (discord.TextChannel, discord.Thread)):
        return
    try:
        message = await channel.fetch_message(msg_id)
    except discord.HTTPException:
        return

    session = ACTIVE_POSTS[msg_id]
    author = guild.get_member(session.author_id)
    member = guild.get_member(payload.user_id)
    if not member or not author:
        return

    emoji = str(payload.emoji)

    if emoji == EMOJI_CONFIRM:
        if any(j.user_id == member.id for j in session.joiners):
            return
        if len(session.joiners) >= session.players_needed:
            try:
                await member.send("❌ That LFG is already full.")
            except Exception:
                pass
            return
        ok = await prompt_joiner_setup(message, member, session)
        if ok:
            await message.edit(embed=build_listing_embed(session, author, guild))

    elif emoji == EMOJI_CANCEL:
        before = len(session.joiners)
        session.joiners = [j for j in session.joiners if j.user_id != member.id]
        after = len(session.joiners)
        if before != after:
            await message.edit(embed=build_listing_embed(session, author, guild))

    elif emoji == EMOJI_RIGHT:
        try:
            if isinstance(channel, discord.TextChannel):
                thread = await message.create_thread(name=f"Team — {author.display_name}'s LFG")
                await thread.send(f"{author.mention} created a team thread. Use this to coordinate.")
        except discord.HTTPException:
            pass

# ---- Minimal HTTP app (health endpoints) ----

app = FastAPI()

@app.get("/")
def root():
    return JSONResponse({"ok": True, "service": "ow2-lfg-bot", "status": "running"})

@app.get("/healthz")
def health():
    return JSONResponse({"status": "ok"})

# --------------- ENTRYPOINT ---------------

async def main():
    if not TOKEN:
        raise SystemExit("Please set DISCORD_TOKEN in the environment.")

    # Uvicorn server
    port = int(os.getenv("PORT", "8080"))
    config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="info")
    server = uvicorn.Server(config)

    async def start_bot():
        try:
            await bot.start(TOKEN)
        finally:
            await bot.close()

    # Run both concurrently
    await asyncio.gather(server.serve(), start_bot())

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
