# Overwatch 2 LFG Discord Bot — Free 24/7 Koyeb Deploy

A reaction‑driven **Overwatch 2 LFG** bot that asks for your **game mode, role, hero** (via server roles named after heroes in all‑lowercase), and **rank range** if Competitive, then posts a live **LFG embed** where members react to join. Works with **discord.py 2.x**.

This repo is pre‑wired to deploy **free and 24/7** on **Koyeb** (one free always‑on Web Service with 512MB RAM / 0.1 vCPU).

- Koyeb Free Tier FAQ (always‑free instance): https://www.koyeb.com/docs/faqs/pricing  → “One `free` web Service ... 512MB RAM, 0.1 vCPU … You can join the Hobby plan without adding a credit card.”
- The container exposes a tiny HTTP server for Koyeb health checks and runs the Discord bot concurrently.

## Quick start (local)

```bash
python -m venv .venv && source .venv/bin/activate   # on Windows: .venv\Scripts\activate
pip install -r requirements.txt
export DISCORD_TOKEN=YOUR_BOT_TOKEN   # Windows PowerShell: $env:DISCORD_TOKEN="..."
python main.py
```

Invite the bot (Gateway Intents: **Server Members** and **Message Content**) then in any channel:

- `!lfg_set #your-lfg-channel`
- `!lfg` to start the reaction wizard

## One‑click deploy to Koyeb (free)

1. Push this repo to your GitHub account (or upload via the Koyeb UI).
2. Create a **Koyeb** account.
3. **Create Web Service** → **GitHub** → pick your repo.
4. Build method: **Dockerfile** (auto-detected).
5. Set **Environment variable**: `DISCORD_TOKEN` = your bot token.
6. Region: **Washington, D.C.** or **Frankfurt** (the free regions).
7. **Instance type**: select the **free** instance (512MB / 0.1 vCPU).
8. Deploy. The service will be **always on**, and the bot will connect to Discord. Health at `/healthz`.

> Note: Koyeb’s free tier details (free web service, regions, etc.) are documented in their **Pricing FAQ**.

## Commands (summary)

- `!lfg` — launch reaction wizard
- `!lfg_set #channel` — choose where LFG posts are published
- `!help` — help embed

## Why rank range is a *preference*

Since OW2 S10, strict rank‑difference party restrictions were removed in favor of **wide vs. narrow** groups. The bot treats the rank range as a **filter for your listing** rather than a hard rule.

## File layout

```
.
├── Dockerfile
├── README.md
├── main.py          # Discord bot + FastAPI health server
└── requirements.txt
```

---

### Troubleshooting

- **Bot stays offline**: make sure **DISCORD_TOKEN** is set correctly and the bot has **Gateway Intents** enabled in the Discord Developer Portal.
- **No hero roles appear**: create server roles named after heroes (all‑lowercase), e.g. `mei`, `venture`, `kiriko`. The bot falls back to the built‑in roster if none exist.
- **Koyeb build fails**: ensure the service uses the **Dockerfile** build and your repo root contains `Dockerfile` and `requirements.txt`.
- **Free plan availability**: Koyeb’s FAQ lists the free instance specs and eligible regions.
